# Barry's Car Sales - accessibility and usability enhancements

Enhanced version of the supplied Barry's Car Sales site (HTML, CSS and JavaScript only; no build step).

Open `index.html` in a browser. Pages: Home (`index.html`), About (`about.html`), Contact / enquiry (`enquiry.html`).

## What was changed
- Alternative text, document language, heading order, link text, lists and table markup corrected (WCAG 1.1.1, 3.1.1, 1.3.1, 2.4.4, 2.4.6).
- Consistent navigation, skip link, landmark labels and current-page marker (2.4.1, 3.2.3, 3.2.4).
- Responsive layout and viewport tag (1.4.4, 1.4.10); visible focus (2.4.7); 24px minimum targets (2.5.8).
- Enquiry form: labels, input types, autocomplete, fieldset, validation with error summary, confirmation message and pre-selected vehicle (1.3.5, 3.3.1-3.3.3, 4.1.3).
- Removed the original `script.js` (a non-keyboard-accessible click handler) and starter notes.

## Known limitations
- The form has no server to receive it on a static host: in demonstration mode it validates and confirms, but nothing is sent. Add `data-endpoint="<form service URL>"` to the form in `enquiry.html` to send enquiries.
- Photos are watermarked stock images and some do not match their listings; they need to be replaced with licensed photographs of the actual cars.
- Team names are placeholder entries.
