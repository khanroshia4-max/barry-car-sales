/* Enquiry form behaviour for Barry's Car Sales
   1. Pre-selects the vehicle from the link that was clicked (?car=...)
   2. Validates the form and identifies errors in text (WCAG 3.3.1, 3.3.3)
   3. Announces success or failure as a status message (WCAG 4.1.3)
*/
(function () {
    'use strict';

    var form = document.getElementById('enquiry-form');
    if (!form) { return; }

    var summary = document.getElementById('error-summary');
    var errorList = document.getElementById('error-list');
    var statusBox = document.getElementById('form-status');
    var carSelect = document.getElementById('car');

    /* 1. Pre-select the vehicle from the query string */
    try {
        var wanted = new URLSearchParams(window.location.search).get('car');
        if (wanted) {
            for (var i = 0; i < carSelect.options.length; i++) {
                if (carSelect.options[i].value === wanted) {
                    carSelect.selectedIndex = i;
                    break;
                }
            }
        }
    } catch (e) { /* older browsers: leave the dropdown on its default */ }

    /* Helpers */
    function field(id) { return document.getElementById(id); }

    function showFieldError(id, message) {
        var input = field(id);
        var out = field(id + '-error');
        out.textContent = 'Error: ' + message;
        out.hidden = false;
        input.setAttribute('aria-invalid', 'true');
    }

    function clearFieldError(id) {
        var input = field(id);
        var out = field(id + '-error');
        if (!out) { return; }
        out.textContent = '';
        out.hidden = true;
        input.removeAttribute('aria-invalid');
    }

    function digitCount(value) { return value.replace(/\D/g, '').length; }

    /* 2. Validation: returns a list of { id, message } */
    function validate() {
        var problems = [];
        var name = field('name').value.trim();
        var email = field('email').value.trim();
        var phone = field('phone').value.trim();
        var contact = form.querySelector('input[name="contact"]:checked');

        if (!name) {
            problems.push({ id: 'name', message: 'Enter your full name.' });
        }

        if (!email) {
            problems.push({ id: 'email', message: 'Enter your email address.' });
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            problems.push({ id: 'email', message: 'Enter an email address in the format name@example.com.' });
        }

        if (phone && (!/^[0-9+()\s-]+$/.test(phone) || digitCount(phone) < 10 || digitCount(phone) > 13)) {
            problems.push({ id: 'phone', message: 'Enter a telephone number with 10 to 13 digits, for example 01707 111 222.' });
        } else if (!phone && contact && contact.value === 'phone') {
            problems.push({ id: 'phone', message: 'Enter a telephone number, because you chose phone as your contact method.' });
        }

        return problems;
    }

    function renderSummary(problems) {
        errorList.innerHTML = '';
        problems.forEach(function (p) {
            var li = document.createElement('li');
            var a = document.createElement('a');
            a.href = '#' + p.id;
            a.textContent = p.message;
            a.addEventListener('click', function (ev) {
                ev.preventDefault();
                field(p.id).focus();
            });
            li.appendChild(a);
            errorList.appendChild(li);
        });
        summary.hidden = false;
        summary.focus();
    }

    /* 3. Status messages */
    function showStatus(text, isError) {
        statusBox.textContent = text;
        statusBox.className = isError ? 'status-box status-error' : 'status-box';
        statusBox.hidden = false;
        statusBox.focus();
    }

    function succeed(isDemo) {
        var name = field('name').value.trim();
        var car = carSelect.options[carSelect.selectedIndex].text;
        var about = carSelect.value ? ' about the ' + car : '';
        form.reset();
        form.hidden = true;
        if (isDemo) {
            showStatus('Thank you, ' + name + '. Your enquiry' + about + ' has been checked. This is a demonstration site, so nothing was actually sent.', false);
        } else {
            showStatus('Thank you, ' + name + '. Your enquiry' + about + ' has been sent. We aim to respond within two working days.', false);
        }
    }

    form.addEventListener('submit', function (ev) {
        ev.preventDefault();

        ['name', 'email', 'phone'].forEach(clearFieldError);
        summary.hidden = true;
        statusBox.hidden = true;

        var problems = validate();
        if (problems.length) {
            problems.forEach(function (p) { showFieldError(p.id, p.message); });
            renderSummary(problems);
            return;
        }

        var endpoint = form.getAttribute('data-endpoint');
        if (!endpoint) {
            /* Demonstration mode (static site, no server to receive the form) */
            succeed(true);
            return;
        }

        fetch(endpoint, {
            method: 'POST',
            body: new FormData(form),
            headers: { 'Accept': 'application/json' }
        }).then(function (response) {
            if (response.ok) { succeed(false); }
            else { showStatus('Sorry, your enquiry could not be sent. Please try again or call 01707 111 222.', true); }
        }).catch(function () {
            showStatus('Sorry, your enquiry could not be sent. Please check your connection and try again, or call 01707 111 222.', true);
        });
    });

    /* Clear a field's error as soon as the person edits it */
    ['name', 'email', 'phone'].forEach(function (id) {
        field(id).addEventListener('input', function () { clearFieldError(id); });
    });
})();
